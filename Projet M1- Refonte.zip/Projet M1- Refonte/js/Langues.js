// JavaScript Document

// GRAVITATION
function appa_grav_ang()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','./Data-pages/theo_grav_ang.html');
	}
function appa_grav_fr()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','./Data-pages/theorie_gravitation.html');
	}

function ang_appa_grav_ang()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','../Data-pages/theo_grav_ang.html');
	}
function ang_appa_grav_fr()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','../Data-pages/theorie_gravitation.html');
	}

//COSMOLOGIE
function appa_cosmo_ang()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','./Data-pages/theo_cosmo_ang.html');
	}
function appa_cosmo_fr()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','./Data-pages/theorie_cosmologie.html');
	}
function angv_appa_fr()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','../Data-pages/theorie_cosmologie.html');
	}

	function angv_appa_ang()
	{
		theo=document.getElementById("theorie");
		theo.setAttribute('data','../Data-pages/theo_cosmo_ang.html');
	}
	

//INDEX

function Version_Fr() {
	window.open("index.html");
}

function Version_Ang() {
	window.open("index_ang.html");
}


function menu() {
	document.getElementsByTagName("ul").style.display = "block";
}


// MENUS 
let navLinks = document.querySelector('.navNarrow');
let narrowLinks = document.querySelector('.narrowLinks');

navLinks.addEventListener('click', toggle);

function toggle() {
	narrowLinks.classList.toggle('hidden');
};