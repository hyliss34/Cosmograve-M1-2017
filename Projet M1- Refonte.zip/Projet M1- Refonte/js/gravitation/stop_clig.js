function stopclig() {

	clearInterval(periode);

}
