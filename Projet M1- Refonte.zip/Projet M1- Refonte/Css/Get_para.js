// JavaScript Document
function param(){alert("lol");}