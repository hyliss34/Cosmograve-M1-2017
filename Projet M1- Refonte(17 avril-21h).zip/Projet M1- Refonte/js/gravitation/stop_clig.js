function stopclig() {

	clearInterval(periode);

}
