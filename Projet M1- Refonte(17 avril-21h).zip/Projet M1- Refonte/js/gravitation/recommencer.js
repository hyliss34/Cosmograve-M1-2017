function reset() {

	alert("Terminé");
	//context.clearRect(0, 0, canvas.width, canvas.height);

}
